package com.example.entity;

public class Subject {
    private Integer subId;
    private String subName;

    public Integer getSubId() {
        return subId;
    }

    public void setSubId(Integer subId) {
        this.subId  = subId;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName  = subName;
    }

    @Override
    public String toString() {
        return "Subject{" +
                "subId=" + subId +
                ", subName='" + subName + '\'' +
                '}';
    }
}