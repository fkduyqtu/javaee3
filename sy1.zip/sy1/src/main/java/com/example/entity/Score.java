package com.example.entity;

public class Score {
    private Integer stuId;
    private Double score;

    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId  = stuId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score  = score;
    }

    @Override
    public String toString() {
        return "Score{" +
                "stuId=" + stuId +
                ", score=" + score +
                '}';
    }
}