package com.example.entity;

import com.example.entity.Subject;

public class Student {
    private Integer stuId;
    private String stuName;
    private Integer age;
    private String sex;
    private Integer gradeId;
    private Double score;
    private java.util.List<Subject> subjects;
    private java.util.List<Student> students;


    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getGradeId() {
        return gradeId;
    }

    public void setGradeId(Integer gradeId) {
        this.gradeId = gradeId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public java.util.List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(java.util.List<Subject> subjects) {
        this.subjects = subjects;
    }

    @Override
    public String toString() {
        return "Student{" +
                "stuId=" + stuId +
                ", stuName='" + stuName + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                ", gradeId=" + gradeId +
                ", score=" + score +
                ", subjects=" + subjects +
                '}';
    }
}