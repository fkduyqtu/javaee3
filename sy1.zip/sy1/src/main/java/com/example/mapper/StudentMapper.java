package com.example.mapper;

import com.example.entity.Grade;
import com.example.entity.Student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface StudentMapper {

    // (1) 增删改查
    List<Student> getAllStudents();
    Student getStudentById(Integer stuId);
    int insertStudent(Student student);
    int updateStudent(Student student);
    int deleteStudent(Integer stuId);

    // (2) 多条件查询
    List<Student> findStudents(@Param("stuName") String stuName,
                               @Param("age") Integer age,
                               @Param("sex") String sex);

    // (3) 关联查询
    List<Student> getStudentsWithScore();
    List<Grade> getGradesWithStudents();
    List<Student> getStudentsWithSubjects();
}
