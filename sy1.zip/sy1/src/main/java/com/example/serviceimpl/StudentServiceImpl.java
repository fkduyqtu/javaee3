package com.example.serviceimpl;

import com.example.entity.Student;
import com.example.mapper.StudentMapper;
import com.example.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Override
    @Transactional
    public void testTransaction() {
        //插入一个新的学生
        Student newStu = new Student();
        newStu.setStuName("事务测试学生");
        newStu.setAge(19);
        newStu.setSex("M");
        newStu.setGradeId(2);
        studentMapper.insertStudent(newStu);
        System.out.println("插入学生成功，ID: " + newStu.getStuId());

        //模拟一个运行时异常
        System.out.println("准备模拟异常...");
       int i = 1 / 0; // 这里会抛出 ArithmeticException

        //如果没有异常，则删除一个学生
        System.out.println("如果没异常，这里会执行删除操作");
        studentMapper.deleteStudent(1);
    }
}
