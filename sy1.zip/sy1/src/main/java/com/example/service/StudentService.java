package com.example.service;
public interface StudentService {
    //测试事务管理的方法
    void testTransaction();
}
