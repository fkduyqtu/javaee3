package com.example;

import com.example.entity.*;
import com.example.mapper.StudentMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class TestStudentMapper {

    private static SqlSessionFactory sqlSessionFactory;

    @BeforeClass
    public static void init() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        inputStream.close();
    }
//增
    @Test
    public void testCRUD1() {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            Student newStu = new Student();
            newStu.setStuName(" 七七");
            newStu.setAge(20);
            newStu.setSex("F");
            newStu.setGradeId(1);

            int result = mapper.insertStudent(newStu);
            System.out.println(" 插入成功，受影响行数: " + result);
            System.out.println(" 已增加学生名字: " + newStu.getStuName());

            System.out.println("===  所有学生及其成绩 ===");
            List<Student> students = mapper.getStudentsWithScore();
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }
    //删
    @Test
    public void testCRUD2() {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            Integer studentIdToDelete = 4 ;  // 假设要删除 ID 为 4 的学生
            int result2 = mapper.deleteStudent(studentIdToDelete);

            if (result2 > 0) {
                System.out.println("✅  成功删除 ID 为 " + studentIdToDelete + " 的学生！");
            } else {
                System.out.println("❌  未找到 ID 为 " + studentIdToDelete + " 的学生！");
            }
            System.out.println("===  所有学生及其成绩 ===");
            List<Student> students = mapper.getStudentsWithScore();
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }


    //改
    @Test
    public void testCRUD() {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("\n===  修改学生信息 ===");
            Student updateStudent = mapper.getStudentById(3);  // 先查询 ID=1 的学生
            if (updateStudent != null) {
                System.out.println(" 修改前: " + updateStudent);

                // 修改属性
                updateStudent.setStuName(" 陆梅丹"); // 新名字
                updateStudent.setAge(18);           // 新年龄
                updateStudent.setSex("F");          // 性别
                updateStudent.setGradeId(2);        // 升级到大二
                updateStudent.setScore(99.0);       //修改成绩
                // 执行更新操作
                int result3 = mapper.updateStudent(updateStudent);
                if (result3 > 0) {
                    System.out.println(" 更新成功！影响行数: " + result3);
                } else {
                    System.out.println(" 更新失败！");
                }


                // 更新结果
                Student updated = mapper.getStudentById(1);
                System.out.println(" 修改后: " + updated);
            } else {
                System.out.println(" 未找到 ID 为 3 的学生！");
            }
            System.out.println("===  所有学生及其成绩 ===");
            List<Student> students = mapper.getStudentsWithScore();
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }

    //查
    @Test
    public void testCRUD4() {
        try (SqlSession session = sqlSessionFactory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("\n===  ID=1 的学生 ===");
            System.out.println(mapper.getStudentById(1));

            System.out.println("===  所有学生及其成绩 ===");
            List<Student> students = mapper.getStudentsWithScore();
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }

    @Test
    public void testDynamicQuery() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);
            System.out.println("===  姓名含‘张’，年龄20 ===");
            List<Student> list = mapper.findStudents("张", 20, null);
            for (Student s : list) {
                System.out.println(s);
            }
        }
    }

    @Test
    public void testOneToOne() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);
            System.out.println("===  学生及成绩 ===");
            List<Student> list = mapper.getStudentsWithScore();
            for (Student s : list) {
                System.out.println(s.getStuName() + " -> 成绩: " + s.getScore());
            }
        }
    }

    @Test
    public void testOneToMany() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);
            System.out.println("===  年级及学生 ===");
            List<Grade> grades = mapper.getGradesWithStudents();
            for (Grade g : grades) {
                System.out.println(" 年级: " + g.getGradeName());
                for (Student s : g.getStudents()) {
                    System.out.println("   - " + s.getStuName());
                }
            }
        }
    }

    @Test
    public void testManyToMany() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);
            System.out.println("===  学生及其课程 ===");
            List<Student> students = mapper.getStudentsWithSubjects();
            for (Student s : students) {
                System.out.println(" 学生: " + s.getStuName());
                if (s.getSubjects() != null) {
                    for (Subject sub : s.getSubjects()) {
                        System.out.println("   - 课程: " + sub.getSubName());
                    }
                }
            }
        }
    }
}