package com.example;

import com.example.entity.Grade;
import com.example.entity.Student;
import com.example.mapper.StudentMapper;
import com.example.service.StudentService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class StudentSpringTest {

    @Autowired
    private StudentService studentService;

    @Autowired
    private StudentMapper studentMapper;

    // 测试事务回滚
    @Test
    public void testTransactionRollback() {
        System.out.println("----- 开始测试事务回滚 -----");
        try {
            studentService.testTransaction();
        } catch (Exception e) {
            System.out.println("捕获到异常: " + e.getClass().getSimpleName());
        }
        System.out.println("----- 测试结束，请检查数据库中是否没有新增 '事务测试学生' -----");
    }

    // 测试 (1) 注解增删改查
    @Test
    public void testAnnotationCRUD() {
        System.out.println("----- 测试注解增删改查 -----");
        // 增
        Student stu = new Student();
        stu.setStuName("陆六（Spring新增学生）");
        stu.setAge(22);
        stu.setSex("F");
        stu.setGradeId(2);
        studentMapper.insertStudent(stu);
        System.out.println("新增学生ID: " + stu.getStuId());
        System.out.println("新增学生信息: 姓名=" + stu.getStuName() +
                ", 年龄=" + stu.getAge() +
                ", 性别=" + stu.getSex() +
                ", 年级ID=" + stu.getGradeId());
        // 查
        Student foundStu = studentMapper.getStudentById(stu.getStuId());
        System.out.println("查询到: " + foundStu.getStuName());

        // 改
        foundStu.setStuName("陆七（修改的学生名字）");
        studentMapper.updateStudent(foundStu);
        System.out.println("修改后名字: " + studentMapper.getStudentById(stu.getStuId()).getStuName());

        // 删
        studentMapper.deleteStudent(stu.getStuId());
        System.out.println("删除成功");
    }

    // 测试 (2) 动态SQL
    @Test
    public void testDynamicSql() {
        System.out.println("----- 测试动态SQL -----");
        System.out.println("--- 查询姓名含'张'的学生 ---");
        List<Student> students = studentMapper.findStudents("张", null, null);
        students.forEach(s -> System.out.println(s.getStuName()));

        System.out.println("--- 查询年龄为20的学生 ---");
        students = studentMapper.findStudents(null, 20, null);
        students.forEach(s -> System.out.println(s.getStuName()));
    }

    // 测试 (3) 复杂映射
    @Test
    public void testComplexMapping() {
        System.out.println("----- 测试复杂映射 -----");
        // 一对一
        System.out.println("--- 一对一：学生及其成绩 ---");
        List<Student> studentsWithScore = studentMapper.getStudentsWithScore();
        studentsWithScore.forEach(s -> System.out.println(s.getStuName() + " -> 成绩: " + (s.getScore() != null ? s.getScore() : "N/A")));

        // 一对多
        System.out.println("\n--- 一对多：年级及其学生 ---");
        List<Grade> gradesWithStudents = studentMapper.getGradesWithStudents();
        gradesWithStudents.forEach(g -> {
            System.out.println("年级: " + g.getGradeName());
            g.getStudents().forEach(s -> System.out.println("  - " + s.getStuName()));
        });

        // 多对多
        System.out.println("\n--- 多对多：学生及其课程 ---");
        List<Student> studentsWithSubjects = studentMapper.getStudentsWithSubjects();
        studentsWithSubjects.forEach(s -> {
            System.out.println("学生: " + s.getStuName());
            if (s.getSubjects() != null && !s.getSubjects().isEmpty()) {
                s.getSubjects().forEach(sub -> System.out.println("  - 课程: " + sub.getSubName()));
            } else {
                System.out.println("  - 无课程");
            }
        });
    }

}
